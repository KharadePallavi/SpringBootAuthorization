package com.example.democrosoriginmyClient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemocrosoriginMyClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
