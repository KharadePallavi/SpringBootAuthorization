package com.example.demoldapbasedonauthorization;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoldapbasedonauthorizationApplicationTests {

	@Test
	void contextLoads() {
	}

}
