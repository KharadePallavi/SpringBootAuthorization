package com.example.demoldapbasedonauthorization.controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/rest")
public class ApplicationController {

	
	@CrossOrigin(origins = "http://localhost:9090")
	@GetMapping("/secure")
	public String secureMethod() {
		return "Secure Method";
	}
}
