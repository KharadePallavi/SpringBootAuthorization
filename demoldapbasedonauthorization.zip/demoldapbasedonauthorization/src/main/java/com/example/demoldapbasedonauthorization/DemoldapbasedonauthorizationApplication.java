package com.example.demoldapbasedonauthorization;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoldapbasedonauthorizationApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoldapbasedonauthorizationApplication.class, args);
	}

}
