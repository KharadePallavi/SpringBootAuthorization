package com.example.demoRoleBasedAuthentication.model;

public enum PostStatus {
	PENDING, APPROVED, REJECTED;
}
