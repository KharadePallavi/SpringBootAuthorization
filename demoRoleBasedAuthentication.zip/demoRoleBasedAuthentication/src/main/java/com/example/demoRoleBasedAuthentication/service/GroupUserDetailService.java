package com.example.demoRoleBasedAuthentication.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.example.demoRoleBasedAuthentication.model.User;
import com.example.demoRoleBasedAuthentication.repository.UserRepository;
@Service
public class GroupUserDetailService implements UserDetailsService {

	@Autowired
	private UserRepository userRepository;
	
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		Optional<User> user=userRepository.findByUserName(username);
		
		return user.map(GroupUserDetails::new)
				.orElseThrow(()->new UsernameNotFoundException(username+"doesn't exist in system") );
	}

}
