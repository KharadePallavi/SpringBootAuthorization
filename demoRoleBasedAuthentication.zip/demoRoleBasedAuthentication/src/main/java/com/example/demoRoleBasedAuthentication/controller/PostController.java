package com.example.demoRoleBasedAuthentication.controller;

import java.security.Principal;
import java.util.List;

import javax.annotation.security.RolesAllowed;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demoRoleBasedAuthentication.model.Post;
import com.example.demoRoleBasedAuthentication.model.PostStatus;
import com.example.demoRoleBasedAuthentication.repository.PostRepository;

@RestController
@RequestMapping("/post")
public class PostController {

	@Autowired
	private PostRepository postRepository;

	@PostMapping("/create")
	public String createPost(@RequestBody Post post, Principal principal) {
		post.setStatus(PostStatus.PENDING);
		post.setUserName(principal.getName());
		postRepository.save(post);
		return principal.getName() + " Your post published Successfully, Required ADMIN/MODERATOR Action: "
				+ post.getStatus();

	}

	@RolesAllowed("ROLE_ADMIN or ROLE_MODERATOR")
	@PreAuthorize("hasAuthority('ROLE_ADMIN') or hasAuthority('ROLE_MODERATOR')")
	@GetMapping("/approvepost/{postId}")
	public String approvePost(@PathVariable int postId) {
		Post post = postRepository.findById(postId).get();
		post.setStatus(PostStatus.APPROVED);
		postRepository.save(post);
		return "POST APPROVED";

	}

	// error in the code gives null output
	@RolesAllowed("ROLE_ADMIN or ROLE_MODERATOR")
	@PreAuthorize("hasAuthority('ROLE_ADMIN') or hasAuthority('ROLE_MODERATOR')")
	@GetMapping("/approveall")
	public String approveAll() {
		
		List<Post> postlist= postRepository.findAll();
		for(Post post:postlist ) {
			if(post.getStatus()==PostStatus.PENDING) {
				post.setStatus(PostStatus.APPROVED);
				postRepository.save(post);
			}
		}
		return "all posts Approved !" ;
		
	}

	@RolesAllowed("ROLE_ADMIN or ROLE_MODERATOR")
	@PreAuthorize("hasAuthority('ROLE_ADMIN') or hasAuthority('ROLE_MODERATOR')")
	@GetMapping("/removepost/{postId}")
	public String deletePost(@PathVariable int postId) {
		Post post = postRepository.findById(postId).get();
		post.setStatus(PostStatus.REJECTED);
		postRepository.save(post);
		return "Post Rejected";
	}

	// error in the code gives null output
	@GetMapping("/rejectall")
	@RolesAllowed("ROLE_ADMIN or ROLE_MODERATOR")
	@PreAuthorize("hasAuthority('ROLE_ADMIN') or hasAuthority('ROLE_MODERATOR')")
    public String rejectAll() {
		List<Post> postlist= postRepository.findAll();
		for(Post post:postlist ) {
			if(post.getStatus()==PostStatus.PENDING) {
				post.setStatus(PostStatus.REJECTED);
				postRepository.save(post);
			}
		}
		
        return "All posts Rejected!";
    }

	// error in the code gives null output
	@GetMapping("/viewall")
	public List<Post> viewAll() {
		List<Post> postlist= postRepository.findAll();
		return postlist;
		
	}
}