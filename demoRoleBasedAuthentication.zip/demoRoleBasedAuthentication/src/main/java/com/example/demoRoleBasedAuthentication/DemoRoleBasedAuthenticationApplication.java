package com.example.demoRoleBasedAuthentication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoRoleBasedAuthenticationApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoRoleBasedAuthenticationApplication.class, args);
	}

}
