package com.example.demoJWTAuthorization;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.demoJWTAuthorization.model.User;
import com.example.demoJWTAuthorization.repository.UserRepository;

@SpringBootApplication
public class DemoJwtAuthorizationApplication {

	@Autowired
	private UserRepository userRepository;

	@PostConstruct
	public void initUsers() {

		List<User> users = Stream.of(new User(101, "Pallavi Kharade", "Pallavi", "Pk@gmail.com"),
				new User(104, "Nanda Kharade", "Nanda", "Pk@gmail.com"),
				new User(102, "Ajay Kharade", "Ajay", "Pk@gmail.com"),
				new User(103, "Vijay Kharade", "Vijay", "Pk@gmail.com")).collect(Collectors.toList());
		userRepository.saveAll(users);

	}

	public static void main(String[] args) {
		SpringApplication.run(DemoJwtAuthorizationApplication.class, args);
	}

}
