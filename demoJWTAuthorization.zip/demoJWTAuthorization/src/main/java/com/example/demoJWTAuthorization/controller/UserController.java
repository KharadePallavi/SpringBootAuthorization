package com.example.demoJWTAuthorization.controller;

import java.util.Enumeration;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;

import org.apache.tomcat.util.http.parser.Authorization;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.JwtException;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demoJWTAuthorization.model.AuthenticationRequest;
import com.example.demoJWTAuthorization.utility.JwtUtil;

@RestController
public class UserController {

	@Autowired
	private JwtUtil jwtUtil;
	@Autowired
	private AuthenticationManager authenticationManager;

    @Value("${spring.security.oauth2.resourceserver.jwt.issuer-uri}")
    private String issuerUri;
    
    
	@GetMapping("/")
	public String welcome(HttpServletRequest servletRequest) throws Exception {
		
	System.out.println(servletRequest.getHeaderNames());
	 HttpServletRequest httpRequest = (HttpServletRequest) servletRequest;
	    Enumeration<String> headerNames = httpRequest.getHeaderNames();

	    if (headerNames != null) {
	            while (headerNames.hasMoreElements()) {
	                    System.out.println("Header: " + httpRequest.getHeader(headerNames.nextElement()));
	            }
	    }
	    return "welcome";
	}
	

	@PostMapping("/authenticate")
	public String generateToken(@RequestBody AuthenticationRequest authrequest) throws Exception {
		try {
			authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(authrequest.getUserName(), authrequest.getPassword()));
		} catch (Exception e) {
			// TODO: handle exception

			throw new Exception("Invalid Username and Password");
		}
		return jwtUtil.generateToken(authrequest.getUserName());

	}
}
