package com.example.demoJWTAuthorization.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demoJWTAuthorization.model.User;

public interface UserRepository extends JpaRepository<User,Integer> {

	User findByUserName(String username);

}
