package com.example.demoautherization.confiiguration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@SuppressWarnings("deprecation")
@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class SecurityConfig  {

//	@Override
//	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
//		auth.inMemoryAuthentication().withUser("Java Techie").password("Password").roles("ADMIN");
//		auth.inMemoryAuthentication().withUser("Basant").password("Password2").roles("USER");
//	}

	// security for all API

	
//	  @Override protected void configure(HttpSecurity http) throws Exception {
//	  http.csrf().disable();
//	  //http.authorizeRequests().anyRequest().fullyAuthenticated().and().
//	  //httpBasic();
//	  }
	 

	// security based on URL

//	@Override
//	protected void configure(HttpSecurity http) throws Exception {
//		http.csrf().disable();
//		http.authorizeRequests().antMatchers("/rest/**").fullyAuthenticated().and().httpBasic();
//	}

	// security based on ROLE
//	@Override
//	protected void configure(HttpSecurity http) throws Exception {
//		http.csrf().disable();
//		http.authorizeRequests().antMatchers("/rest/**").hasAnyRole("ADMIN").anyRequest().fullyAuthenticated().and()
//				.httpBasic();
//	}
//
//	@Bean
//	public static NoOpPasswordEncoder passwordEncoder() {
//		return (NoOpPasswordEncoder) NoOpPasswordEncoder.getInstance();
//	}


	@Autowired
	private UserDetailsService userDetailsService;
	
	protected void configure(AuthenticationManagerBuilder auth) throws Exception{
	auth.userDetailsService(userDetailsService).passwordEncoder(encoder());
	}
	
	
	protected void configure(HttpSecurity http) throws Exception{
		http.csrf().disable();
//		http.authorizeRequests().antMatchers("/rest/**").authenticated().anyRequest().permitAll().and()
//		.authorizeRequests().antMatchers("/secure/**").authenticated().anyRequest().hasAnyRole("ADMIN").and()
//		.formLogin().permitAll();
		
		
		 http.httpBasic().and().authorizeRequests().antMatchers("/rest/**").permitAll().and()
	     .authorizeRequests().antMatchers("/secure/**").hasAnyRole("Admin").anyRequest().permitAll();		  
	}
	   
	@Bean
	public BCryptPasswordEncoder encoder() {
		return new BCryptPasswordEncoder();
	}
	
	
}
